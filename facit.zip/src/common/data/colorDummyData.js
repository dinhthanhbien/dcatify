const COLORS = {
	PRIMARY: 'primary',
	SECONDARY: 'secondary',
	INFO: 'info',
	WARNING: 'warning',
	DANGER: 'danger',
	SUCCESS: 'success',
	LIGHT: 'light',
	DARK: 'dark',
};
export default COLORS;
